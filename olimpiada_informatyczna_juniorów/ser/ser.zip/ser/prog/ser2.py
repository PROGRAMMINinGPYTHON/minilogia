# Wczytujemy zmienna N i zamieniamy
# ja na liczbe (wczesniej to byl napis).
N = int(input())

# Poniższa pętla wykonuje się N razy.
# N razy wypisujemy pojedyncze serce.
for i in range(N):
  # Wypisujemy serce linijka po linijce.
  print(" @@@   @@@ ")
  print("@   @ @   @")
  print("@    @    @")
  print("@         @")
  print(" @       @ ")
  print("  @     @  ")
  print("   @   @   ")
  print("    @ @    ")
  print("     @     ")
